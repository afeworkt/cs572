const fibonacci =require('./fibonacci');

const fib30=fibonacci(14);
console.log("fibionacci of 30", fib30);
const fibNegative15=fibonacci(-15);
console.log("fibionacci of -15", fibNegative15);